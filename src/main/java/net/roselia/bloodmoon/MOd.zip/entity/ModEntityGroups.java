package net.roselia.bloodmoon.entity;

import net.minecraft.entity.SpawnGroup;

public class ModEntityGroups {
    public static final SpawnGroup BLOOD_PROJECTILES = SpawnGroup.MISC; 
}
