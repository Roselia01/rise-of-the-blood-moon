package net.roselia.bloodmoon.entity;

import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;

public class TrackedNeedle {
    private final LivingEntity entity;
    private int needleCount = 1;
    private int ticksLeft = 120;

    public TrackedNeedle(LivingEntity entity) {
        this.entity = entity;
    }

    public void resetTimer() {
        ticksLeft = 120;
        if (needleCount < 7) {
            needleCount++;
        }
    }

    public boolean tickDown(ServerWorld world) {
        if (!entity.isAlive()) return true;

        if (--ticksLeft <= 0) {
            explode(world);
            return true;
        }

        return false;
    }

    private void explode(ServerWorld world) {
        float damage;
        Vec3d pos = entity.getPos();

        if (needleCount == 1) {
            damage = 2.0f;
        } else if (needleCount == 2) {
            damage = 4.0f * 2;
        } else {
            damage = 6.0f * needleCount;
        }

        entity.damage(world.getDamageSources().explosion(null), damage);

        // Send explosion sound to everyone nearby
        world.playSound(
            null, // send to all nearby players
            pos.x, pos.y, pos.z,
            SoundEvents.ENTITY_GENERIC_EXPLODE,
            SoundCategory.HOSTILE,
            4.0f, // volume
            1.0f  // pitch
        );

        // Send particles to ALL clients manually
        ((ServerWorld) world).spawnParticles(
            ParticleTypes.EXPLOSION_EMITTER,
            pos.x, pos.y, pos.z,
            1, // count
            0.0, 0.0, 0.0, // spread
            0.0 // speed
        );


        System.out.println(">> explode() was called! needleCount=" + needleCount);
        System.out.println("Is server: " + !world.isClient);
    }
}